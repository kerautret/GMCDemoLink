<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


<?php include("cpt.php") ?>





   <h2> Curvature Estimator Demo: Global Minimisation Curvature (GMC)</h2>


<DIV id="saisie">

Choose sample image:
</span> 
<form method="post" enctype="multipart/form-data" action="computeCurvatureFromImage.php">
<p>
<TABLE width=10% >
<TR>
<TD width=10% > <img src="ImagesTests/shape1.gif" width=150px >  </TD>
<TD width=10% > <img src="ImagesTests/shape2.gif" width=150px >  </TD>
<TD width=10% > <img src="ImagesTests/shape3.gif" width=150px >  </TD>
</TR>
<TR>
<td align=center>  <input type="radio" name="sampleNum" value="1" > </td>
<td align=center> <input type="radio" name="sampleNum" value="2"  > </td>
<td align=center> <input type="radio" name="sampleNum" value="3"  > </td>
</TR>

</TABLE>
<BR>
     or upload grayscale image (contour threshold set to 128).
<br>
<td align=center> <input type="file" name="fichierImage" size="20">  </td>
<br>

<br>
<input type="submit" name="computeBoxes" value="Compute Curvature">

</p>
</form>








<hr color=#330090  width=800px align=left > 
<tr id="Kerautret2009a" class="entry"> 
<td>[Kerautret09a] <a href="http://www.loria.fr/~kerautre"> Kerautret, B.</a>, <a href="http://www.lama.univ-savoie.fr/~lachaud"> Lachaud, J.-O </a> (2009), <i>"Curvature Estimation along Noisy Digital Contours by Approximate Global Optimization"</i>, Pattern Recognition, Volume 42 (10) pp. 2265-2278   

<a href="http://www.loria.fr/~kerautre/publications/Kerautret08c.pdf">[PDF]</a>
<a href="http://www.sciencedirect.com/"> [Elsevier Sciencedirecte]</a>.  
</tr>


</DIV>




<DIV id="resultats">

<?php  

if("$_POST[inputImageOK]"=="ok"){

  include("computeCurvatureFromImage.php");

}

?>


</body>
</html>
