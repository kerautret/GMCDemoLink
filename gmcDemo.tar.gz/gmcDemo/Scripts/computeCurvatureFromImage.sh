#!/bin/sh


ImageName=$1
TempFilePath=/home/kerautre/Sites/gmc/uploadFiles



# Convert Image to FC chain.


export LD_LIBRARY_PATH=/usr/local/lib/



/usr/local/bin/pgm2freeman --min 128 -i $ImageName > ${TempFilePath}/contour.fc 2> ${TempFilePath}/log2.txt; cat ${TempFilePath}/log2.txt| cut -f 3,4 -d " " > ${TempFilePath}/size.txt ;


/usr/local/bin/curvature_gmc < ${TempFilePath}/contour.fc > ${TempFilePath}/curvature.dat
cd ${TempFilePath}
/usr/bin/gnuplot pltCurvature 
#/usr/local/bin/freeman2pgm < contour.fc > srcContour.pgm  2> ${TempFilePath}/log3.txt;
/usr/local/bin/freeman2sdp --FreemanChain contour.fc > contour.sdp 2> ${TempFilePath}/log3.txt;
/usr/bin/gnuplot pltContour




