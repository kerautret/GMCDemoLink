

<?php



$tabSelectImage = array("1" => "/home/kerautre/Sites/gmc/ImagesTests/shape1.gif",
			"2" => "/home/kerautre/Sites/gmc/ImagesTests/shape2.gif",
			"3" => "/home/kerautre/Sites/gmc/ImagesTests/shape3.gif");
			


$tmp_file = $_FILES['fichierImage']['tmp_name'];

if( !is_uploaded_file($tmp_file) ){  
  $PathImage=$tabSelectImage[$_POST['sampleNum']];
  system("convert $PathImage uploadFiles/imageContour.pgm"); 
}else{
  $type_file = $_FILES['fichierImage']['type'];
  $typeExt = $_FILES['fichierImage']['ext'];
  
  if( preg_match('#[\x00-\x1F\x7F-\x9F/\\\\]#', $name_file)){   	
    exit("Nom de fichier non valide");
  }			
  
  $allowed_types = array("image/pjpeg" => ".jpeg",
		       "image/jpeg" => ".jpeg",
			 "image/gif" => ".gif",
			 "x-png" => ".png",
			 "image/x-portable-graymap" => ".pgm");
  
  
  foreach ($allowed_types as $nameType => $extension){
    if( $type_file == $nameType ){
      $nameToConvert = "fileUploaded"."$extension";
      move_uploaded_file($tmp_file, "uploadFiles/$nameToConvert");
      system("convert uploadFiles/$nameToConvert uploadFiles/imageContour.pgm"); 
    }  
  }
  
}




system("/home/kerautre/Sites/gmc/Scripts/computeCurvatureFromImage.sh  /home/kerautre/Sites/gmc/uploadFiles/imageContour.pgm ");


include('index.php');



echo('<BR> <img src="uploadFiles/curvature.gif" width=256px>');
echo('<BR> <a href="uploadFiles/curvature.dat"> curvature.dat </a>');
echo('<BR> <a href="uploadFiles/srcContour.gif"> srcContour.gif </a>');
echo('<BR> <a href="uploadFiles/curvature.gif">  curvature.gif </a>');
echo('<BR> <a href="uploadFiles/contour.sdp">  contour.sdp </a>');



?>