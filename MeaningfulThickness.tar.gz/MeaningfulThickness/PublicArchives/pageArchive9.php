<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=9; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 80  (ID: Archive_1128123341110)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1128123341110/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1128123341110/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1128123341110/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1128123341110/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1128123341110/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1128123341110/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :983 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 2160 surfels <BR> Sampling size max used: 15 # Noise estimation stats: Mean:2.11806 variance: 1.33653 Min: 1 Max: 10
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 81  (ID: Archive_0027513351210)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0027513351210/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0027513351210/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0027513351210/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0027513351210/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0027513351210/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0027513351210/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :1016 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 2160 surfels <BR> Sampling size max used: 15 # Noise estimation stats: Mean:2.11806 variance: 1.33653 Min: 1 Max: 10
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 82  (ID: Archive_1055271090411)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1055271090411/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1055271090411/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1055271090411/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1055271090411/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1055271090411/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1055271090411/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :268 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 450 surfels <BR> Sampling size max used: 15 # Noise estimation stats: Mean:3.06 variance: 3.74529 Min: 1 Max: 10
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 83  (ID: Archive_1105211090411)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1105211090411/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1105211090411/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1105211090411/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1105211090411/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1105211090411/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1105211090411/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :257 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 450 surfels <BR> Sampling size max used: 15 # Noise estimation stats: Mean:3.06 variance: 3.74529 Min: 1 Max: 10
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 84  (ID: Archive_1105291090411)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1105291090411/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1105291090411/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1105291090411/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1105291090411/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1105291090411/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1105291090411/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :265 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 450 surfels <BR> Sampling size max used: 15 # Noise estimation stats: Mean:3.06 variance: 3.74529 Min: 1 Max: 10
 </TD></TR>  </TABLE> 
</DIV>
</DIV>

	
	</BODY>
</HTML> 
