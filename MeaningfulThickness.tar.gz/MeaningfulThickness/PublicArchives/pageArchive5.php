<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=5; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 40  (ID: Archive_1555151090410)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1555151090410/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1555151090410/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1555151090410/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1555151090410/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1555151090410/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1555151090410/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :17 ms <BR> Contour size: 138 surfels <BR> Sampling size max used: 7
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 41  (ID: Archive_1555491090410)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1555491090410/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1555491090410/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1555491090410/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1555491090410/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1555491090410/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1555491090410/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :16 ms <BR> Contour size: 136 surfels <BR> Sampling size max used: 7
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 42  (ID: Archive_1152501100410)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1152501100410/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1152501100410/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1152501100410/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1152501100410/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1152501100410/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1152501100410/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :293 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 544 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 43  (ID: Archive_1821591160410)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1821591160410/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1821591160410/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1821591160410/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1821591160410/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1821591160410/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1821591160410/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :436 ms <BR> Contour size: 828 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 44  (ID: Archive_1426371520610)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1426371520610/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1426371520610/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1426371520610/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1426371520610/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1426371520610/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1426371520610/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :432 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 778 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 45  (ID: Archive_1836442710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1836442710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1836442710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1836442710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1836442710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1836442710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1836442710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :292 ms <BR> Contour size: 494 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 46  (ID: Archive_1927472710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1927472710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1927472710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1927472710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1927472710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1927472710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1927472710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :462 ms <BR> Contour size: 874 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 47  (ID: Archive_1929082710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1929082710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1929082710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1929082710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1929082710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1929082710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1929082710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :445 ms <BR> Contour size: 874 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 48  (ID: Archive_1934592710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1934592710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1934592710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1934592710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1934592710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1934592710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1934592710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :20 ms <BR> Contour size: 226 surfels <BR> Sampling size max used: 6
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 49  (ID: Archive_1936212710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1936212710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1936212710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1936212710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1936212710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1936212710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1936212710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :21 ms <BR> Contour size: 226 surfels <BR> Sampling size max used: 6
 </TD></TR>  </TABLE> 
</DIV>
