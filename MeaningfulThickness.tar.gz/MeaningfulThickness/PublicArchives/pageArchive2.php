<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=2; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 10  (ID: Archive_1245233001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1245233001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1245233001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1245233001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1245233001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1245233001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1245233001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :564 ms <BR> Contour threshold: 180, min size: 300 <BR> Contour size: 1224 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 11  (ID: Archive_1247013001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1247013001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1247013001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1247013001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1247013001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1247013001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1247013001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :2471 ms <BR> Contour size: 4612 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 12  (ID: Archive_1250583001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1250583001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1250583001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1250583001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1250583001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1250583001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1250583001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :3224 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 6458 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 13  (ID: Archive_1302003001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1302003001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1302003001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1302003001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1302003001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1302003001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1302003001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :1255 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 2674 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 14  (ID: Archive_1316503001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1316503001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1316503001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1316503001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1316503001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1316503001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1316503001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :491 ms <BR> Contour size: 966 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 15  (ID: Archive_1605263001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1605263001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1605263001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1605263001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1605263001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1605263001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1605263001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :4430 ms <BR> Contour size: 5732 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 16  (ID: Archive_1614413001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1614413001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1614413001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1614413001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1614413001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1614413001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1614413001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :1533 ms <BR> Contour threshold: 190, min size: 300 <BR> Contour size: 2216 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 17  (ID: Archive_1618003001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1618003001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1618003001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1618003001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1618003001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1618003001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1618003001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :2212 ms <BR> Contour threshold: 210, min size: 300 <BR> Contour size: 3440 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 18  (ID: Archive_1730293001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1730293001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1730293001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1730293001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1730293001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1730293001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1730293001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :493 ms <BR> Contour size: 980 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 19  (ID: Archive_2258163001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2258163001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2258163001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2258163001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2258163001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2258163001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2258163001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :126 ms <BR> Contour size: 154 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
