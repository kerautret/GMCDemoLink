<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=3; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 20  (ID: Archive_0034053011009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0034053011009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0034053011009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0034053011009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0034053011009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0034053011009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0034053011009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :63 ms <BR> Contour size: 220 surfels <BR> Sampling size max used: 10
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 21  (ID: Archive_0034343011009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0034343011009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0034343011009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0034343011009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0034343011009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0034343011009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0034343011009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :61 ms <BR> Contour size: 224 surfels <BR> Sampling size max used: 10
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 22  (ID: Archive_0101223011009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0101223011009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0101223011009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0101223011009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0101223011009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0101223011009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0101223011009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :1 ms <BR> Contour size: 60 surfels <BR> Sampling size max used: 3
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 23  (ID: Archive_0102043011009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0102043011009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0102043011009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0102043011009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0102043011009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0102043011009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0102043011009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :1 ms <BR> Contour size: 68 surfels <BR> Sampling size max used: 3
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 24  (ID: Archive_0850213011009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0850213011009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0850213011009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0850213011009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0850213011009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0850213011009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0850213011009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :1196 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 2477 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 25  (ID: Archive_1423203011009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1423203011009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1423203011009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1423203011009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1423203011009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1423203011009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1423203011009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :7 ms <BR> Contour threshold: 128, min size: 30 <BR> Contour size: 108 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 26  (ID: Archive_0025563031009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0025563031009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0025563031009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0025563031009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0025563031009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0025563031009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0025563031009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :31 ms <BR> Contour threshold: 120, min size: 200 <BR> Contour size: 282 surfels <BR> Sampling size max used: 7
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 27  (ID: Archive_1632593071109)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1632593071109/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1632593071109/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1632593071109/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1632593071109/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1632593071109/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1632593071109/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :80 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 320 surfels <BR> Sampling size max used: 10
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 28  (ID: Archive_1737183591209)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1737183591209/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1737183591209/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1737183591209/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1737183591209/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1737183591209/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1737183591209/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :286 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 526 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 29  (ID: Archive_1121520060110)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1121520060110/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1121520060110/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1121520060110/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1121520060110/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1121520060110/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1121520060110/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :297 ms <BR> Contour size: 540 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
