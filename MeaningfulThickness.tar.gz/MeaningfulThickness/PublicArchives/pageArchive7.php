<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=7; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 60  (ID: Archive_2102112720910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2102112720910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2102112720910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2102112720910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2102112720910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2102112720910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2102112720910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :601 ms <BR> Contour size: 1306 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 61  (ID: Archive_2103022720910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2103022720910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2103022720910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2103022720910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2103022720910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2103022720910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2103022720910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :602 ms <BR> Contour size: 1306 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 62  (ID: Archive_1452032741010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1452032741010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1452032741010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1452032741010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1452032741010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1452032741010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1452032741010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :674 ms <BR> Contour size: 1322 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 63  (ID: Archive_1415462851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1415462851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1415462851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1415462851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1415462851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1415462851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1415462851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :568 ms <BR> Contour size: 1306 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.42496 variance: 3.47408 Min: 1 Max: 12
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 64  (ID: Archive_1432352851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1432352851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1432352851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1432352851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1432352851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1432352851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1432352851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :500 ms <BR> Contour size: 998 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.23246 variance: 0.767603 Min: 1 Max: 5
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 65  (ID: Archive_1434442851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1434442851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1434442851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1434442851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1434442851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1434442851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1434442851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :338 ms <BR> Contour size: 708 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.55226 variance: 2.36026 Min: 1 Max: 8
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 66  (ID: Archive_1439202851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1439202851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1439202851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1439202851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1439202851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1439202851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1439202851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :354 ms <BR> Contour size: 708 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.55226 variance: 2.36026 Min: 1 Max: 8
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 67  (ID: Archive_1440482851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1440482851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1440482851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1440482851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1440482851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1440482851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1440482851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :333 ms <BR> Contour size: 708 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.55226 variance: 2.36026 Min: 1 Max: 8
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 68  (ID: Archive_1441052851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1441052851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1441052851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1441052851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1441052851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1441052851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1441052851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :342 ms <BR> Contour size: 708 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.55226 variance: 2.36026 Min: 1 Max: 8
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 69  (ID: Archive_1441232851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1441232851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1441232851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1441232851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1441232851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1441232851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1441232851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :342 ms <BR> Contour size: 708 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.55226 variance: 2.36026 Min: 1 Max: 8
 </TD></TR>  </TABLE> 
</DIV>
