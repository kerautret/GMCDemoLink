 
<a href=pageArchive1.php <?php if($NumPageEnCours == 1){ echo('style="color:#FFFFFF"');} ?> > [1] </a>
<a href=pageArchive2.php <?php if($NumPageEnCours == 2){ echo('style="color:#FFFFFF"');} ?> > [2] </a>
<a href=pageArchive3.php <?php if($NumPageEnCours == 3){ echo('style="color:#FFFFFF"');} ?> > [3] </a>
<a href=pageArchive4.php <?php if($NumPageEnCours == 4){ echo('style="color:#FFFFFF"');} ?> > [4] </a>
<a href=pageArchive5.php <?php if($NumPageEnCours == 5){ echo('style="color:#FFFFFF"');} ?> > [5] </a>
<a href=pageArchive6.php <?php if($NumPageEnCours == 6){ echo('style="color:#FFFFFF"');} ?> > [6] </a>
<a href=pageArchive7.php <?php if($NumPageEnCours == 7){ echo('style="color:#FFFFFF"');} ?> > [7] </a>
<a href=pageArchive8.php <?php if($NumPageEnCours == 8){ echo('style="color:#FFFFFF"');} ?> > [8] </a>
<a href=pageArchive9.php <?php if($NumPageEnCours == 9){ echo('style="color:#FFFFFF"');} ?> > [9] </a>
