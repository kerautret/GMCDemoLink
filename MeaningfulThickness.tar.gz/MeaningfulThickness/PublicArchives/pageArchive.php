
<?php  
 $numFile= fopen("numPages.txt","r");
   $num=intval(fgets($numFile));
   $name="pageArchive$num.php";
   include($name);
?>
