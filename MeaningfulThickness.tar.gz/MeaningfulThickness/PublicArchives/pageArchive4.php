<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=4; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 30  (ID: Archive_1122050060110)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1122050060110/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1122050060110/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1122050060110/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1122050060110/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1122050060110/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1122050060110/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :692 ms <BR> Contour size: 1322 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 31  (ID: Archive_1124200060110)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1124200060110/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1124200060110/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1124200060110/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1124200060110/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1124200060110/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1124200060110/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :445 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 874 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 32  (ID: Archive_1124400060110)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1124400060110/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1124400060110/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1124400060110/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1124400060110/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1124400060110/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1124400060110/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :451 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 874 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 33  (ID: Archive_0206570100110)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0206570100110/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0206570100110/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0206570100110/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0206570100110/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0206570100110/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0206570100110/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :7018 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 13660 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 34  (ID: Archive_1137370390210)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1137370390210/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1137370390210/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1137370390210/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1137370390210/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1137370390210/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1137370390210/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :925 ms <BR> Contour size: 1864 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 35  (ID: Archive_2121110480210)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2121110480210/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2121110480210/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2121110480210/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2121110480210/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2121110480210/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2121110480210/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :536 ms <BR> Contour size: 1192 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 36  (ID: Archive_1503580570210)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1503580570210/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1503580570210/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1503580570210/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1503580570210/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1503580570210/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1503580570210/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :1701 ms <BR> Contour size: 3350 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 37  (ID: Archive_1529220640310)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1529220640310/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1529220640310/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1529220640310/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1529220640310/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1529220640310/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1529220640310/noiseLevel.txt>noiseLevel.txt</a> <br>  
<BR> <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 38  (ID: Archive_1529290640310)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1529290640310/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1529290640310/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1529290640310/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1529290640310/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1529290640310/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1529290640310/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :386 ms <BR> Contour size: 658 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 39  (ID: Archive_1046130670310)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1046130670310/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1046130670310/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1046130670310/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1046130670310/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1046130670310/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1046130670310/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :805 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 1642 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
