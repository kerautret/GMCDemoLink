<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=6; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 50  (ID: Archive_1939052710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1939052710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1939052710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1939052710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1939052710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1939052710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1939052710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :633 ms <BR> Contour size: 1476 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 51  (ID: Archive_1940332710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1940332710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1940332710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1940332710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1940332710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1940332710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1940332710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :23 ms <BR> Contour size: 328 surfels <BR> Sampling size max used: 6
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 52  (ID: Archive_1942182710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1942182710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1942182710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1942182710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1942182710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1942182710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1942182710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :395 ms <BR> Contour size: 702 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 53  (ID: Archive_1946542710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1946542710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1946542710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1946542710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1946542710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1946542710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1946542710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :414 ms <BR> Contour size: 788 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 54  (ID: Archive_1947592710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1947592710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1947592710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1947592710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1947592710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1947592710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1947592710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :384 ms <BR> Contour size: 702 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 55  (ID: Archive_1950562710910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1950562710910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1950562710910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1950562710910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1950562710910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1950562710910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1950562710910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :386 ms <BR> Contour size: 702 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 56  (ID: Archive_2044422720910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2044422720910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2044422720910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2044422720910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2044422720910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2044422720910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2044422720910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :344 ms <BR> Contour size: 708 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 57  (ID: Archive_2053072720910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2053072720910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2053072720910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2053072720910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2053072720910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2053072720910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2053072720910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :433 ms <BR> Contour size: 784 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 58  (ID: Archive_2054072720910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2054072720910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2054072720910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2054072720910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2054072720910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2054072720910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2054072720910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :446 ms <BR> Contour size: 830 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 59  (ID: Archive_2059142720910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2059142720910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2059142720910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2059142720910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2059142720910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2059142720910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2059142720910/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :492 ms <BR> Contour size: 998 surfels <BR> Sampling size max used: 15
 </TD></TR>  </TABLE> 
</DIV>
