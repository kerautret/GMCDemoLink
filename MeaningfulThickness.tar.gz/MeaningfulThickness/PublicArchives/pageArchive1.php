<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php \$NumPageEnCours=1; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 1  (ID: Archive_1240193001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1240193001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1240193001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1240193001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1240193001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1240193001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1240193001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :375 ms <BR> Contour size: 658 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 2  (ID: Archive_1240283001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1240283001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1240283001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1240283001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1240283001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1240283001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1240283001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :218 ms <BR> Contour size: 332 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 3  (ID: Archive_1240363001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1240363001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1240363001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1240363001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1240363001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1240363001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1240363001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :219 ms <BR> Contour size: 332 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 4  (ID: Archive_1240443001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1240443001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1240443001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1240443001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1240443001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1240443001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1240443001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :558 ms <BR> Contour size: 1098 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 5  (ID: Archive_1240543001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1240543001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1240543001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1240543001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1240543001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1240543001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1240543001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :304 ms <BR> Contour size: 540 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 6  (ID: Archive_1241093001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1241093001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1241093001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1241093001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1241093001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1241093001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1241093001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :459 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 874 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 7  (ID: Archive_1241193001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1241193001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1241193001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1241193001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1241193001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1241193001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1241193001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :381 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 694 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 8  (ID: Archive_1241283001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1241283001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1241283001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1241283001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1241283001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1241283001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1241283001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :251 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 450 surfels
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 9  (ID: Archive_1241363001009)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1241363001009/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1241363001009/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1241363001009/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1241363001009/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1241363001009/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1241363001009/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :377 ms <BR> Contour threshold: 128, min size: 300 <BR> Contour size: 778 surfels
 </TD></TR>  </TABLE> 
</DIV>
