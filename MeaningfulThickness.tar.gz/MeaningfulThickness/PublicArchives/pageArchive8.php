<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> Meaningful Scales demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=8; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 70  (ID: Archive_1442112851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1442112851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1442112851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1442112851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1442112851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1442112851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1442112851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :576 ms <BR> Contour size: 1306 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.42496 variance: 3.47408 Min: 1 Max: 12
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 71  (ID: Archive_1442292851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1442292851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1442292851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1442292851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1442292851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1442292851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1442292851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :572 ms <BR> Contour size: 1306 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.42496 variance: 3.47408 Min: 1 Max: 12
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 72  (ID: Archive_1442432851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1442432851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1442432851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1442432851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1442432851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1442432851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1442432851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :568 ms <BR> Contour size: 1306 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.42496 variance: 3.47408 Min: 1 Max: 12
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 73  (ID: Archive_1443562851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1443562851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1443562851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1443562851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1443562851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1443562851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1443562851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :176 ms <BR> Contour size: 244 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:1 variance: 0 Min: 1 Max: 1
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 74  (ID: Archive_1444322851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1444322851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1444322851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1444322851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1444322851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1444322851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1444322851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :171 ms <BR> Contour size: 244 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:1 variance: 0 Min: 1 Max: 1
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 75  (ID: Archive_1444552851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1444552851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1444552851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1444552851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1444552851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1444552851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1444552851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :174 ms <BR> Contour size: 244 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:1 variance: 0 Min: 1 Max: 1
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 76  (ID: Archive_1445242851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1445242851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1445242851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1445242851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1445242851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1445242851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1445242851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :280 ms <BR> Contour size: 522 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.16475 variance: 1.98435 Min: 1 Max: 7
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 77  (ID: Archive_1446042851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1446042851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1446042851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1446042851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1446042851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1446042851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1446042851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :275 ms <BR> Contour size: 522 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.16475 variance: 1.98435 Min: 1 Max: 7
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 78  (ID: Archive_1446192851010)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1446192851010/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1446192851010/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1446192851010/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1446192851010/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1446192851010/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1446192851010/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :281 ms <BR> Contour size: 522 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.16475 variance: 1.98435 Min: 1 Max: 7
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 79  (ID: Archive_1527503271110)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1527503271110/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1527503271110/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1527503271110/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1527503271110/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1527503271110/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1527503271110/noiseLevel.txt>noiseLevel.txt</a> <br>  
Multi-scale computed in :596 ms <BR> Contour size: 1306 surfels <BR> Sampling size max used: 15 <BR> # Noise estimation stats: Mean:2.42496 variance: 3.47408 Min: 1 Max: 12
 </TD></TR>  </TABLE> 
</DIV>
