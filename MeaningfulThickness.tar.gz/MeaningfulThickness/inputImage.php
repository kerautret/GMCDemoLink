




<hr color=#330090  align=left > 

<BR>

<form method="post" enctype="multipart/form-data" action="index.php">
<TABLE width=10% >
<TR>

<TD width=10% > <img src="ImagesExamples/polygoneImageNoise.gif" height=110px >  </TD>
<TD width=10% > <img src="ImagesExamples/squareImageNoise.gif" height=110px >  </TD>
<TD width=10% > <img src="ImagesExamples/flowerImageNoise.gif" height=110px >  </TD>
<TD height =10% > <img src="ImagesExamples/letterSImage.gif" height=70px >  </TD>
</TR>
<TR>
<td align=center>  <input type="radio" name="sampleNum" value="1" > </td>
<td align=center> <input type="radio" name="sampleNum" value="2"  > </td>
<td align=center> <input type="radio" name="sampleNum" value="3"  > </td>
<td align=center> <input type="radio" name="sampleNum" value="4"  > </td>
</TR>
</TABLE>



<input type="hidden" name="inputImagePosted" value="ok">
<input type="hidden" name="inputContourPosted" value="non">

<div id = "fileSelect" >
   Select image file: <br>
   <INPUT type=hidden name=MAX_FILE_SIZE  VALUE=2000000>
 <input type="file" name="fichierImage" size="20">  
   <input type="radio" name="public" value="pubOK" > Leave image in the public domain  
</div>



<BR>
  Contour extraction thresold <input type="text" name ="thresold" value="128" size="3" > min Size <input type="text" name ="minSize" value="300" size="3" > <BR>

   <input type="radio" name="option" value="advanced">  option:  
   x <input type="text" name ="x" value="0" size="3" > 
   y <input type="text" name ="y" value="0" size="3" > 
   maxDistance <input type="text" name ="distance" value="0" size="3" > 
   <BR>
<input type="submit" name="computeThicknessImg" value="Compute Meaningful Thickness">
<input type="submit" name="computeScaleImg" value="Compute Meaningful Scales">
   

</form>

<hr color=#330090  width=800px align=left > 
