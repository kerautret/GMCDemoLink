
<hr color=#330090   align=left > 

<form method="post" enctype="multipart/form-data" action="index.php">
<p>
<center>
<TABLE  >

<TR>
<TD align="CENTER" width="200px"> <img src="ImagesExamples/ellipsePolygonaleNoise.png" width=150px >  </TD>
<TD> <img src="ImagesExamples/flowerPolygonalNoise.png" width=150px >  </TD>
<TD> <img src="ImagesExamples/polygonNoise.png" width=150px >  </TD>
</TR>

<TR>
<td align=center> <input type="radio" name="sampleNum" value="1" checked > </td>
<td align=center> <input type="radio" name="sampleNum" value="2"   > </td>
<td align=center> <input type="radio" name="sampleNum" value="3"  > </td>
</TR>

<TR>
<TD> <img src="ImagesExamples/rsquareSamplingVar.png" width=150px >  </TD>
<TD> <img src="ImagesExamples/rsquareSamplingVarNoisy.png" width=150px >  </TD>
<TD> <img src="ImagesExamples/contourOuvert.png" width=150px >  </TD>
</TR>
<TR>
<td align=center> <input type="radio" name="sampleNum" value="4"  > </td>
<td align=center> <input type="radio" name="sampleNum" value="5"  > </td>
<td align=center> <input type="radio" name="sampleNum" value="6"  > </td>

</TR>
</TABLE>
</center>


<div id = "fileSelect" >
   Select a polygonal contour: (format: X Y coordinates in each line) <br>
   
   <INPUT type=hidden name=MAX_FILE_SIZE  VALUE=10000>
   <input type="file" name="fichierContour" size="20">  
   <input type="radio" name="public" value="pubOK" > Leave contour in the  public domain 
</div>

</td>

<br>
<input type="hidden" name="inputImagePosted" value="non">
<input type="hidden" name="inputContourPosted" value="ok">
<input type="submit" name="computeThickness" value="Compute Meaningful Thickness">
<input type="submit" name="denoising" value="Polygon denoising">

</p>
</form>
