<?php
 system("/home/kerautre/Sites/MeaningfulBoxes/Scripts/generateArchivePage.sh"); 
?>