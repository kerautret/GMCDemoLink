


<? // Compteur PHP de hits

$fichier="compteur.txt";
$date =  date("D M j G:i:s T Y");
$domaineF="domaines.txt";
$domaine= gethostbyaddr(getenv("HTTP_X_FORWARDED_FOR" )  
        ? getenv("HTTP_X_FORWARDED_FOR" )  
        : getenv("REMOTE_ADDR" )); 
preg_match("/[^\.\/]+\.[^\.\/]+$/",$domaine,$chaines);
$refer=$_SERVER["HTTP_REFERER"];
$inF2 = fopen($domaineF,"a");




fputs($inF2,$date." ");
fputs($inF2,$chaine." ");
fputs($inF2,$domaine." ");
fputs($inF2,$refer."\n");
fclose($inF2);



// Lecture du fichier s'il existe et incr�mente
$cpt = 1;
if(file_exists($fichier)) {
   $inF = fopen($fichier,"r");
   $cpt = intval(trim(fgets($inF, 4096))) + 1; 
   fclose($inF); 
}



// Sauvegarde du compteur
$inF = fopen($fichier,"w");
fputs($inF,$cpt."\n"); 
fclose($inF);


$inF2 = fopen($domaineF,"a");




fputs($inF2,$date." ");
fputs($inF2,$chaine." ");
fputs($inF2,$domaine." ");
fputs($inF2,$refer."\n");
fclose($inF2);
?>

