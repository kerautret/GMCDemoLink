#!/bin/sh







# Génération de toutes les pages contenant les archives (NumParPage) par pages

NumParPage=10;
NumPage=1;

cat /home/kerautre/Sites/MeaningfulBoxes/Scripts/enteteArchive.html  > /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive1.php;
echo '<?php \$NumPageEnCours=1; include("indexArchives.php") ?>' >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive1.php;
NumArchive=1;

for name in $(ls -tr /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/ |grep Archive_[0-9]*) 
do
    reste=$((${NumArchive} % ${NumParPage}));
    if (test $reste -eq 0)
    then        
	NumPage=$(($NumPage+1));
	cat /home/kerautre/Sites/MeaningfulBoxes/Scripts/enteteArchive.html  > /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;

	echo "<?php \$NumPageEnCours=$NumPage; include(\"indexArchives.php\") ?>" >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;
	
    fi
    echo '<HR linewidth=1px>' >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;    
    echo '<div id="archive" >' >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;
    echo "Archive $NumArchive  (ID: $name)"  >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;
    echo "<TABLE> <TR> <TD> <IMG width=150px SRC= ${name}/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= ${name}/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=${name}/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=${name}/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=${name}/tmp.pdf>result.pdf</a> <BR>
    <a href=${name}/noiseLevel.txt>noiseLevel.txt</a> <br>  " >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;
    
    
    echo $(cat /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/${name}/info.txt ) >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;
    
    echo " </TD></TR>  </TABLE> " >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;
    echo "</DIV>" >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;    
    NumArchive=$((NumArchive+1))
done 


echo '</DIV>

	
	</BODY>
</HTML> ' >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/pageArchive${NumPage}.php;    






## Génération des liens vers toutes les pages d'archives:

echo " " > /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/indexArchives.php;
echo "$NumPage" > /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/numPages.txt;


for(( i=1; i != ${NumPage}+1 ; i=i+1))
do
    echo "<a href=pageArchive${i}.php <?php if(\$NumPageEnCours == $i){ echo('style=\"color:#FFFFFF\"');} ?> > [${i}] </a>" >> /home/kerautre/Sites/MeaningfulBoxes/PublicArchives/indexArchives.php;
    
done














