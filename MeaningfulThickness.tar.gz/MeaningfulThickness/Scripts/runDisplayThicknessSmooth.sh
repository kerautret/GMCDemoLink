
#!/bin/sh


NAME=$1



cd /home/kerautre/Sites/MeaningfulThickness/;



export LD_LIBRARY_PATH=/usr/local/lib/

/home/kerautre/EnCours/imagene/build/tests/TestCompNoiseDetect/displayNoiseBS -enteteXFIG -drawContourSRC 0 1 40 -exportNoiseLevel noise.dat -srcPolygon ${NAME} 0 1 CLOSED  -displaySmoothContour  4 -autoScale -estimClosedContour > FichiersTmp/tmp.fig  2> FichiersTmp/log.txt ; fig2dev  -L eps -m 0.5 tmp.fig tmp.eps ;
fig2dev  -L png -m 0.5  FichiersTmp/tmp.fig FichiersTmp/tmp.png
fig2dev  -L pdf -m 0.5  FichiersTmp/tmp.fig FichiersTmp/tmp.pdf




cat FichiersTmp/log.txt |grep "Meaningful Thickness computed in " > FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Noise removed  in" >> FichiersTmp/info.txt ;
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Size" >> FichiersTmp/info.txt ;
echo "<BR>" >> FichiersTmp/info.txt;




# Sauvegarde des fichiers sources dans l'archive
cp ${NAME} FichiersTmp/contourSRC.sdp;



convert FichiersTmp/tmp.png FichiersTmp/tmp.gif;









