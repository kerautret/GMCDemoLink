
#!/bin/sh


NAMEIMAGE=$1

TH=$2

MINSIZE=$3

cd /home/kerautre/Sites/MeaningfulThickness;
REP="/home/kerautre/Sites/MeaningfulThickness";


export LD_LIBRARY_PATH=/usr/local/lib/


if( test  $# -eq 6 )
then 
    /usr/local/bin/pgm2freeman -threshold $TH -min_size $MINSIZE < $NAMEIMAGE -selectContour $4 $5 $6 > FichiersTmp/contour.fc 2> FichiersTmp/log.txt ; cat FichiersTmp/log2.txt | cut -f 3,4 -d " " > FichiersTmp/size.txt  ;
else
    /usr/local/bin/pgm2freeman -threshold $TH -min_size $MINSIZE < $NAMEIMAGE  > FichiersTmp/contour.fc 2> FichiersTmp/log2.txt; cat FichiersTmp/log2.txt| cut -f 3,4 -d " " > FichiersTmp/size.txt ;
fi

SIZE=$(cat FichiersTmp/size.txt);

convert $NAMEIMAGE FichiersTmp/imageFond.gif;
convert $NAMEIMAGE FichiersTmp/imageFond.png;



/home/kerautre/EnCours/imagene/build/tests/TestCompNoiseDetect/displayNoiseBS -enteteXFIG -drawContourSRC 4 1 40 -srcFC FichiersTmp/contour.fc -autoScale  -drawNoiseLevelBoxes 1   -afficheImage imageFond.png $SIZE > FichiersTmp/tmp.fig 2> FichiersTmp/log.txt ; fig2dev  -L eps -m 0.5  FichiersTmp/tmp.fig FichiersTmp/tmp.eps
fig2dev  -L png -m 0.5  FichiersTmp/tmp.fig FichiersTmp/tmp.png
fig2dev  -L pdf -m 0.5  FichiersTmp/tmp.fig FichiersTmp/tmp.pdf



# Sauvegarde des fichiers sources dans l'archive
cp FichiersTmp/imageFond.gif FichiersTmp/contourSRC.gif;
cp FichiersTmp/contour.fc FichiersTmp/contourSRC.fc;



cat FichiersTmp/log.txt |grep "Meaningful Thickness computed in " > FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Size" >> FichiersTmp/info.txt ;
echo "<BR>" >> FichiersTmp/info.txt;


epstopdf  FichiersTmp/tmp.eps;
pdftoppm FichiersTmp/tmp.pdf FichiersTmp/tmp.ppm ;
convert FichiersTmp/tmp.ppm-1.ppm FichiersTmp/tmp.gif;









