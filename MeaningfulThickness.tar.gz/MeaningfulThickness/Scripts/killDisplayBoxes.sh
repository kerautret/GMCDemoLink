#!/bin/sh

 for pid in $(ps -xa | grep displayBoxe | cut -d " " -f 1) ; do  kill -9 $pid ; done 