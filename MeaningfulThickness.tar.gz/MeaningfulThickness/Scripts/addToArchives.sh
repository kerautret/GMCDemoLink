#!/bin/sh


#copie fichiers resultats temporaires dans un répertoire archive:

ID=$(date +%H%M%S%j%m%y);









NAMEREP="/home/kerautre/Sites/MeaningfulBoxes/PublicArchives/Archive_$ID";
mkdir ${NAMEREP};

cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/tmp.gif  ${NAMEREP}/ ;
cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/tmp.eps  ${NAMEREP}/ ;
cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/tmp.pdf  ${NAMEREP}/ ;
cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/tmp.fig  ${NAMEREP}/ ;
cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/log.txt  ${NAMEREP}/ ;
cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/noiseLevel.txt  ${NAMEREP}/ ;
cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/info.txt  ${NAMEREP}/ ;
cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/contourSRC.fc  ${NAMEREP}/ ;
cp /home/kerautre/Sites/MeaningfulBoxes/FichiersTmp/contourSRC.gif  ${NAMEREP}/ ;











