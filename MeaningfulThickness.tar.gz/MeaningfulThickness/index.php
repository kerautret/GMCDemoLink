<HTML>
<HEAD>
<TITLE>Meaningful Thickness Demo </TITLE>
<LINK type="text/css" rel="stylesheet" href="demoStyle.css">
</HEAD>
		

<BODY>
<DIV id="conteneur">
<?php include("cpt.php") ?>
   <h2> Meaningful Thickness Demo </h2>
   
<br>
<br>
</DIV>	





<DIV id="saisie">
<h4> Choose or upload a polygonal contour  </h4>
<?php include("inputPolygon.php") ?>



<h4> Choose or upload an image and  select a contour threshold  </h4>
<?php include("inputImage.php") ?>
</DIV>



<DIV id="resultats">
			

<?php  
   
   $sourceDemoPath = "/home/kerautre/Sites/MeaningfulThickness";
   $pubDomain = $_POST['public'];

   if("$_POST[inputContourPosted]"=="ok"){
     $tabSelectImage = array("1" => "$sourceDemoPath/ImagesExamples/ellipsePolygonaleNoise.sdp",
			     "2" => "$sourceDemoPath/ImagesExamples/flowerPolygonalNoise.sdp",
			     "3" => "$sourceDemoPath/ImagesExamples/polygonNoise.sdp",
			     "4" => "$sourceDemoPath/ImagesExamples/rsquareSamplingVar.sdp",
			     "5" => "$sourceDemoPath/ImagesExamples/rsquareSamplingVarNoisy.sdp",
			     "6" => "$sourceDemoPath/ImagesExamples/contourOuvert.sdp");
     
     $tmp_file = $_FILES['fichierContour']['tmp_name'];
     $size=$_FILES['fichierContour']['size'];
     if($_FILES['fichierContour']['error']==2 || $size >100000 ){
       exit("File size exceeds maximal size: $size  (max=10ko) "); 
     }
     if( !is_uploaded_file($tmp_file) ){  
       $PathImage=$tabSelectImage[$_POST['sampleNum']];  
     }else{
       move_uploaded_file($tmp_file,"$sourceDemoPath/FichiersTmp/contourTmp.fc");
       $PathImage="$sourceDemoPath/FichiersTmp/contourTmp.fc";
     }
     if($_POST['computeThickness']){
	 exec("$sourceDemoPath/Scripts/runDisplayThickness.sh  $PathImage");     
     }else if($_POST['denoising']){
         exec("$sourceDemoPath/Scripts/runDisplayThicknessSmooth.sh  $PathImage");     
     }
     echo('<BR><BR> <img  width=256px src=FichiersTmp/tmp.gif >');
     echo('<BR>');
     echo('<a href="FichiersTmp/tmp.pdf"> result.pdf </a>');
     echo('<BR>');
     echo('<BR>');
     echo('<a href="FichiersTmp/noise.dat"> noise.dat </a>');
     echo(system("cat $sourceDemoPath/FichiersTmp/info.txt"));
     if($pubDomain == "pubOK"){
       system("$sourceDemoPath/Scripts/addToArchives.sh");
       system("$sourceDemoPath/Scripts/generateArchivePage.sh");
     }
   }



   else if(("$_POST[inputImagePosted]"=="ok") and  
	   (is_numeric($_POST['thresold']))  and  
	   (is_numeric($_POST['minSize']))){
     

     $tabSelectImage = array("1" => "$sourceDemoPath/ImagesExamples/polygoneImageNoise.gif",
			     "2" => "$sourceDemoPath/ImagesExamples/squareImageNoise.gif",
			     "3" => "$sourceDemoPath/ImagesExamples/flowerImageNoise.gif",
			     "4" => "$sourceDemoPath/ImagesExamples/letterSImage.gif");
     
     
     $tmp_file = $_FILES['fichierImage']['tmp_name'];
     $size=$_FILES['fichierImage']['size'];
     if($_FILES['fichierImage']['error']==2 || $size >1000000 ){
       exit("File size exceeds maximal size: $size  (max=2Mo) "); 
     }
     

     if($_FILES['fichierImage']['error']==2){
       exit("Fichier de taille trop grande (max=2Mo) "); 
     }
     
     if( !is_uploaded_file($tmp_file) ){  
       $num=$_POST['sampleNum'];
       if($num=="")
	 $num="1";
       
       $PathImage=$tabSelectImage[$num];
       system("convert $PathImage FichiersTmp/imageContour.pgm"); 
     }else{
       $type_file = $_FILES['fichierImage']['type'];
       $typeExt = $_FILES['fichierImage']['ext'];

       if( preg_match('#[\x00-\x1F\x7F-\x9F/\\\\]#', $name_file)){   	
	 exit("Nom de fichier non valide");
       }			
       
       
       $allowed_types = array("image/pjpeg" => ".jpeg",
			      "image/jpeg" => ".jpeg",
			      "image/gif" => ".gif",
			      "x-png" => ".png",
			      "image/x-portable-graymap" => ".pgm");
       
  
       foreach ($allowed_types as $nameType => $extension){
	 if( $type_file == $nameType ){
	   $nameToConvert = "fileUploaded"."$extension";
	   move_uploaded_file($tmp_file, "FichiersTmp/$nameToConvert");
	   system("convert FichiersTmp/$nameToConvert FichiersTmp/imageContour.pgm"); 
	 }  
       }
       
     }
     
     
     
     $th=$_POST['thresold'];
     $minSize = $_POST['minSize'];
     $pubDomain = $_POST['public'];
     
     
     $x=$_POST['x'];
     $y=$_POST['y'];
     $distance=$_POST['distance'];
     $advanced=$_POST['option'];
     
     if($_POST['computeThicknessImg']){
       if($advanced=="advanced"){
	 system("$sourceDemoPath/Scripts/runDisplayThicknessImage.sh  FichiersTmp/imageContour.pgm $th $minSize  $x $y $distance ");
     }else{
       system("$sourceDemoPath/Scripts/runDisplayThicknessImage.sh  FichiersTmp/imageContour.pgm $th $minSize ");
       }
     }
     else if($_POST['computeScaleImg']){
       if($advanced=="advanced"){
	 system("$sourceDemoPath/Scripts/runDisplayScaleImage.sh  FichiersTmp/imageContour.pgm $th $minSize  $x $y $distance ");
       }else{
	 system("$sourceDemoPath/Scripts/runDisplayScaleImage.sh  FichiersTmp/imageContour.pgm $th $minSize ");
       }
     }
     echo('<BR> <BR> <img  width=256px src="FichiersTmp/tmp.gif" >');
     echo('<BR>');
     echo('<a href="FichiersTmp/tmp.pdf"> result.pdf </a> <BR>');     
     echo('<BR>');
     echo('<a href="FichiersTmp/noise.dat"> noise.dat </a>');

     system("cat $sourceDemoPath/FichiersTmp/info.txt");
     
     if($pubDomain == "pubOK"){
       system("$sourceDemoPath/Scripts/addToArchives.sh");
       system("$sourceDemoPath/Scripts/generateArchivePage.sh");
     }
     
   }
   else if(("$_POST[inputImagePosted]"=="ok") and  !((is_numeric($_POST['thresold']))and  (is_numeric($_POST['minSize'])))){
     echo ("<color =red>Non numerics parameter field</color>");
     
   }


?>



</DIV>
	
</BODY>
</HTML>
